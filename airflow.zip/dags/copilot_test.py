def read_file(file_path):
    with open(file_path, 'r') as file:
        content = file.read()
    return content

# function for writing a file
def write_file(file_path, content):
    with open(file_path, 'w') as file:
        file.write(content)

# function for reading a SQLite table
def read_sqlite_table(table_name, input_file_path):
    conn = sqlite3.connect(input_file_path)
    cursor = conn.cursor()
    cursor.execute(f'SELECT * FROM {table_name}')
    data = cursor.fetchall()
    conn.close()
    return data

# function for writing a SQLite table
def write_sqlite_table(table_name, data, output_file_path):
    conn = sqlite3.connect(output_file_path)
    cursor = conn.cursor()
    cursor.execute(f'CREATE TABLE IF NOT EXISTS {table_name} (id INTEGER PRIMARY KEY, name TEXT)')
    cursor.executemany(f'INSERT INTO {table_name} (id, name) VALUES (?, ?)', data)
    conn.commit()
    conn.close()

# function for reading a SQLite table using Pandas
def read_sqlite_table_pandas(table_name, input_file_path):
    df = pd.read_sql_query(f'SELECT * FROM {table_name}', sqlite3.connect(input_file_path))
    return df

# function for writing a SQLite table using Pandas
def write_sqlite_table_pandas(table_name, data, output_file_path):
    data.to_sql(table_name, sqlite3.connect(output_file_path), if_exists='replace', index=False)

# function for logging
def log_first_row(data):
    first_row = data.head(1)
    print(f'Logging first row:\n{first_row}')

# function for logging using logging
def log_first_row_logger(data):
    first_row = data.head(1)
    logging.info(f'Logging first row:\n{first_row}')

# function for logging using logging
def log_first_row_logger_with_context(**kwargs):
    ti = kwargs['ti']
    data = ti.xcom_pull(task_ids='read_from_sqlite')
    first_row = data.head(1)
    logging.info(f'Logging first row:\n{first_row}')

# function for logging using logging
def log_first_row_logger_with_context_and_jinja(**kwargs):
    ti = kwargs['ti']
    data = ti.xcom_pull(task_ids='read_from_sqlite')
    first_row = data.head(1)
    logging.info(f'Logging first row:\n{first_row}')
    logging.info(f'DAG ID is {kwargs["dag"].dag_id}')
    logging.info(f'Execution date is {kwargs["execution_date"]}')
    logging.info(f'File path is {kwargs["dag"].default_args["file_path"]}')

# function for logging using logging
def log_first_row_logger_with_context_and_jinja_and_params(**kwargs):
    ti = kwargs['ti']
    data = ti.xcom_pull(task_ids='read_from_sqlite')
    first_row = data.head(1)
    logging.info(f'Logging first row:\n{first_row}')
    logging.info(f'DAG ID is {kwargs["dag"].dag_id}')
    logging.info(f'Execution date is {kwargs["execution_date"]}')
    logging.info(f'File path is {kwargs["dag"].default_args["file_path"]}')
    logging.info(f'Param1 is {kwargs["dag_run"].conf["param1"]}')
    logging.info(f'Param2 is {kwargs["dag_run"].conf["param2"]}')

# function for logging using logging
def log_first_row_logger_with_context_and_jinja_and_params_and_branch(**kwargs):
    ti = kwargs['ti']
    data = ti.xcom_pull(task_ids='read_from_sqlite')
    first_row = data.head(1)
    logging.info(f'Logging first row:\n{first_row}')
    logging.info(f'DAG ID is {kwargs["dag"].dag_id}')
    logging.info(f'Execution date is {kwargs["execution_date"]}')
    logging.info(f'File path is {kwargs["dag"].default_args["file_path"]}')
    logging.info(f'Param1 is {kwargs["dag_run"].conf["param1"]}')
    logging.info(f'Param2 is {kwargs["dag_run"].conf["param2"]}')
    logging.info(f'Branch is {kwargs["dag_run"].conf["branch"]}')



